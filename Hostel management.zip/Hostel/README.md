# Hostel-management--
This website provide a feature to manage the  all rooms in a hostel . you can see what room are allocated to you with room number . admin can see their room number as well as name of the student .
#Working
student :
1 student can register firstly 
2 login the profile
3 applay for hostel room
4 see allocated room details 

Admin :
1 login using user name and password
2 it can change the room no add the room number and also add the branches 
3 see the student data 
4 register the student 

Author by :-
sdmcoder (shubham)
